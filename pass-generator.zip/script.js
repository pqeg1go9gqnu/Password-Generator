function generatePassword() {
    const length = document.getElementById('length').value;
    const useUppercase = document.getElementById('uppercase').checked;
    const useLowercase = document.getElementById('lowercase').checked;
    const useNumbers = document.getElementById('numbers').checked;
    const useSymbols = document.getElementById('symbols').checked;

    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+[]{}|;:,.<>?';

    let charset = '';
    if (useUppercase) charset += upper;
    if (useLowercase) charset += lower;
    if (useNumbers) charset += numbers;
    if (useSymbols) charset += symbols;

    if (charset.length === 0) {
        alert('Seleziona almeno un tipo di carattere.');
        return;
    }

    let password = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }

    document.getElementById('password').value = password;
}

function copyPassword() {
    const passwordField = document.getElementById('password');
    passwordField.select();
    document.execCommand('copy');
    alert('Password copiata negli appunti!');
}

function toggleLang() {
    const menu = document.getElementById('lang-menu');
    menu.classList.toggle('hidden');
}

function setLang(lang) {
    const texts = {
        en: {
            title: "Password Generator",
            lengthLabel: "Length:",
            uppercase: "Uppercase",
            lowercase: "Lowercase",
            numbers: "Numbers",
            symbols: "Symbols",
            generate: "Generate Password",
            copy: "Copy"
        },
        it: {
            title: "Generatore di Password",
            lengthLabel: "Lunghezza:",
            uppercase: "Maiuscole",
            lowercase: "Minuscole",
            numbers: "Numeri",
            symbols: "Simboli",
            generate: "Genera Password",
            copy: "Copia"
        },
        es: {
            title: "Generador de Contraseñas",
            lengthLabel: "Longitud:",
            uppercase: "Mayúsculas",
            lowercase: "Minúsculas",
            numbers: "Números",
            symbols: "Símbolos",
            generate: "Generar Contraseña",
            copy: "Copiar"
        }
    };

    const text = texts[lang];
    document.getElementById('title').textContent = text.title;
    document.querySelector('label[for="length"]').textContent = text.lengthLabel;
    document.getElementById('uppercase').nextSibling.textContent = text.uppercase;
    document.getElementById('lowercase').nextSibling.textContent = text.lowercase;
    document.getElementById('numbers').nextSibling.textContent = text.numbers;
    document.getElementById('symbols').nextSibling.textContent = text.symbols;
    document.querySelector('button[onclick="generatePassword()"]').textContent = text.generate;
    document.querySelector('button[onclick="copyPassword()"]').textContent = text.copy;
}

function openDiscord() {
    window.open('https://discord.gg/gQREKRmnQR', '_blank');
}
